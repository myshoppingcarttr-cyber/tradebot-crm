// ============================================
// TRADEBOT — Node.js Backend
// Vapi Webhook + Supabase + Piyasa Analizi
// ============================================
// Kurulum: npm install express @supabase/supabase-js node-cron axios dotenv

require('dotenv').config();
const express    = require('express');
const cron       = require('node-cron');
const axios      = require('axios');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(express.json());

// Supabase bağlantısı
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY  // service_role key kullan
);

// -----------------------------------------------
// SKOR HESAPLAMA
// -----------------------------------------------
function calculateScore(outcome, duration, currentScore) {
  const delta = {
    'account_opened': +40,
    'appointment':    +25,
    'callback':       +15,
    'info_given':     +10,
    'no_answer':      -5,
    'not_interested': -10,
  }[outcome] ?? 0;

  // Konuşma süresi bonus (3 dakika üstü +5)
  const durationBonus = duration > 180 ? 5 : 0;

  return Math.max(0, Math.min(100, currentScore + delta + durationBonus));
}

// -----------------------------------------------
// VAPI WEBHOOK
// -----------------------------------------------
app.post('/vapi/webhook', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.json({ ok: true });

  const type = message.type;
  console.log('[Vapi]', type);

  // --- Arama bitti ---
  if (type === 'end-of-call-report') {
    const call = message.call;
    const phone = call.customer?.number;

    // Lead bul veya oluştur
    let lead = null;
    if (phone) {
      const { data } = await supabase
        .from('leads')
        .select('id, score')
        .eq('phone', phone)
        .single();

      if (data) {
        lead = data;
      } else if (call.type === 'inbound') {
        // Inbound: yeni lead kaydet
        const { data: newLead } = await supabase
          .from('leads')
          .insert({ phone, source: 'inbound', status: 'cold', score: 0 })
          .select()
          .single();
        lead = newLead;
      }
    }

    // Outcome belirle
    const transcript = message.transcript ?? '';
    const outcome = detectOutcome(transcript, message.analysis);

    // Yeni skor hesapla
    const newScore = lead
      ? calculateScore(outcome, call.duration, lead.score)
      : 0;

    // Çağrıyı kaydet
    const { data: savedCall } = await supabase
      .from('calls')
      .insert({
        lead_id:          lead?.id,
        vapi_call_id:     call.id,
        direction:        call.type,
        phone_from:       call.customer?.number,
        phone_to:         call.phoneNumber?.number,
        duration_sec:     call.duration,
        status:           'completed',
        transcript:       transcript,
        summary:          message.analysis?.summary,
        sentiment:        message.analysis?.sentiment,
        outcome:          outcome,
        lead_score_after: newScore,
        escalated:        message.analysis?.escalated ?? false,
      })
      .select()
      .single();

    // Skor log
    if (lead) {
      await supabase.from('lead_score_log').insert({
        lead_id:   lead.id,
        old_score: lead.score,
        new_score: newScore,
        reason:    outcome,
        call_id:   savedCall?.id,
      });
    }

    // Sıcak lead bildirimi
    if (newScore >= 80 && lead) {
      await notifyAdvisor(lead.id, outcome, newScore);
    }

    console.log(`[Call] ${phone} · ${outcome} · Skor: ${lead?.score} → ${newScore}`);
    return res.json({ ok: true });
  }

  // --- Tool call (Vapi araç çağrısı) ---
  if (type === 'tool-calls') {
    const results = [];

    for (const toolCall of message.toolCallList ?? []) {
      const { name, parameters } = toolCall;
      let result = '';

      if (name === 'get_market_analysis') {
        result = await getMarketAnalysisForCall();
      }

      if (name === 'save_lead_info') {
        await supabase.from('leads').upsert({
          phone:     parameters.phone,
          full_name: parameters.name,
          city:      parameters.city,
          interests: parameters.interests,
          source:    'inbound',
        }, { onConflict: 'phone' });
        result = 'Lead bilgisi kaydedildi.';
      }

      if (name === 'check_appointment_slots') {
        result = await getAvailableSlots(parameters.preferred_date);
      }

      if (name === 'create_appointment') {
        const { data: lead } = await supabase
          .from('leads').select('id').eq('phone', parameters.phone).single();

        if (lead) {
          await supabase.from('appointments').insert({
            lead_id:      lead.id,
            scheduled_at: parameters.slot_time,
            advisor_name: parameters.advisor,
            notes:        parameters.notes,
          });
        }
        result = `Randevunuz ${parameters.slot_time} için oluşturuldu.`;
      }

      results.push({ toolCallId: toolCall.id, result });
    }

    return res.json({ results });
  }

  res.json({ ok: true });
});

// -----------------------------------------------
// OUTBOUND KAMPANYA BAŞLAT
// -----------------------------------------------
app.post('/campaigns/start', async (req, res) => {
  const { campaignId } = req.body;

  const { data: campaign } = await supabase
    .from('outbound_campaigns')
    .select('*')
    .eq('id', campaignId)
    .single();

  if (!campaign) return res.status(404).json({ error: 'Kampanya bulunamadı' });

  // Filtreye göre lead listesi çek
  const filter = campaign.target_filter ?? {};
  let query = supabase.from('leads').select('id, phone, full_name');

  if (filter.status?.length)    query = query.in('status', filter.status);
  if (filter.min_score != null) query = query.gte('score', filter.min_score);
  if (filter.max_score != null) query = query.lte('score', filter.max_score);

  const { data: leads } = await query.limit(500);

  // Kampanya durumunu güncelle
  await supabase.from('outbound_campaigns').update({
    status:      'running',
    total_leads: leads.length,
    started_at:  new Date().toISOString(),
  }).eq('id', campaignId);

  // Günlük analizi çek — ajan bu analizle arayacak
  const analysis = await getMarketAnalysisForCall();

  // Vapi outbound aramaları başlat (toplu)
  let called = 0;
  for (const lead of leads) {
    try {
      await axios.post('https://api.vapi.ai/call/phone', {
        assistantId:   campaign.vapi_assistant_id ?? process.env.VAPI_ASSISTANT_ID,
        assistantOverrides: {
          variableValues: {
            customer_name:   lead.full_name ?? 'Değerli Müşteri',
            market_analysis: analysis,
          }
        },
        customer: {
          number: lead.phone,
          name:   lead.full_name,
        },
        phoneNumberId: process.env.VAPI_PHONE_NUMBER_ID,
      }, {
        headers: { 'Authorization': `Bearer ${process.env.VAPI_API_KEY}` }
      });

      called++;
      // Rate limit — Vapi'yi bunaltma
      await sleep(300);
    } catch (err) {
      console.error(`[Outbound] ${lead.phone} hata:`, err.message);
    }
  }

  await supabase.from('outbound_campaigns')
    .update({ called_count: called })
    .eq('id', campaignId);

  res.json({ ok: true, called });
});

// -----------------------------------------------
// GÜNLÜK PİYASA ANALİZİ — CRON JOB
// Her sabah 08:00'de çalışır
// -----------------------------------------------
cron.schedule('0 8 * * 1-5', async () => {
  console.log('[Cron] Günlük piyasa analizi başlatılıyor...');
  await fetchAndSaveMarketAnalysis();
});

async function fetchAndSaveMarketAnalysis() {
  try {
    // --- Piyasa verisini çek ---
    // Alpha Vantage veya Twelve Data kullanabilirsin
    // Burada örnek sabit veri — gerçekte API'den gelir
    const marketData = await fetchMarketPrices();

    // --- Claude ile analiz üret ---
    const analysisPrompt = buildAnalysisPrompt(marketData);

    const claudeRes = await axios.post('https://api.anthropic.com/v1/messages', {
      model:      'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: analysisPrompt }],
    }, {
      headers: {
        'x-api-key':         process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Type':      'application/json',
      }
    });

    const analysisText = claudeRes.data.content[0].text;
    let parsed = {};
    try { parsed = JSON.parse(analysisText); } catch {}

    // Vapi prompt inject metni
    const vapiInject = buildVapiInject(marketData, parsed);

    // Supabase'e kaydet
    await supabase.from('daily_analysis').upsert({
      analysis_date:      new Date().toISOString().split('T')[0],
      market_data:        marketData,
      gold_analysis:      parsed.gold   ?? '',
      fx_analysis:        parsed.fx     ?? '',
      crypto_analysis:    parsed.crypto ?? '',
      stocks_analysis:    parsed.stocks ?? '',
      general_summary:    parsed.summary ?? '',
      sales_scripts:      parsed.scripts ?? {},
      news_events:        parsed.news   ?? [],
      vapi_prompt_inject: vapiInject,
      fetched_at:         new Date().toISOString(),
    }, { onConflict: 'analysis_date' });

    console.log('[Market] Analiz kaydedildi:', new Date().toLocaleDateString('tr-TR'));
  } catch (err) {
    console.error('[Market] Hata:', err.message);
  }
}

function buildAnalysisPrompt(data) {
  return `Sen uzman bir finansal analistsin. Aşağıdaki günlük piyasa verilerini analiz et ve bir Forex/CFD aracı kurumunun satış ajanı için kullanılacak script'leri oluştur.

Piyasa Verisi:
${JSON.stringify(data, null, 2)}

Şu formatta SADECE JSON döndür (başka hiçbir şey yazma):
{
  "gold": "Altın için 2-3 cümlelik satış narrative (Türkçe)",
  "fx": "Forex pariteler için satış narrative (Türkçe)",
  "crypto": "Kripto için satış narrative (Türkçe)",
  "stocks": "Hisse/endeks için satış narrative (Türkçe)",
  "summary": "Genel piyasa özeti 1 paragraf (Türkçe)",
  "scripts": {
    "gold_opener": "Altın için telefon açılış cümlesi",
    "crypto_opener": "Kripto için telefon açılış cümlesi",
    "fx_opener": "Forex için telefon açılış cümlesi",
    "urgency_hook": "Aciliyet yaratan genel cümle"
  },
  "news": [
    { "time": "16:00", "event": "Önemli haber adı", "impact": "high" }
  ]
}`;
}

function buildVapiInject(marketData, analysis) {
  const gold   = marketData['XAUUSD'];
  const btc    = marketData['BTCUSD'];
  const eurusd = marketData['EURUSD'];

  return `
=== GÜNLÜK PİYASA BİLGİSİ (${new Date().toLocaleDateString('tr-TR')}) ===
- ALTIN: $${gold?.price} (${gold?.change_pct > 0 ? '+' : ''}${gold?.change_pct}%)
- BTC: $${btc?.price} (${btc?.change_pct > 0 ? '+' : ''}${btc?.change_pct}%)
- EUR/USD: ${eurusd?.price} (${eurusd?.change_pct > 0 ? '+' : ''}${eurusd?.change_pct}%)

SATIŞ NARRATİVLERİ:
Altın: ${analysis.gold ?? ''}
Kripto: ${analysis.crypto ?? ''}
Forex: ${analysis.fx ?? ''}

AÇILIŞ CÜMLELERİ:
- Altın leadler: "${analysis.scripts?.gold_opener ?? ''}"
- Kripto leadler: "${analysis.scripts?.crypto_opener ?? ''}"
- Aciliyet: "${analysis.scripts?.urgency_hook ?? ''}"
=== ===`.trim();
}

async function getMarketAnalysisForCall() {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('daily_analysis')
    .select('vapi_prompt_inject')
    .eq('analysis_date', today)
    .single();

  return data?.vapi_prompt_inject ?? 'Piyasa verisi henüz yüklenmedi.';
}

async function fetchMarketPrices() {
  // Twelve Data ücretsiz API (8 sembol/dk)
  // Gerçek projede: https://api.twelvedata.com/price?symbol=XAU/USD&apikey=KEY
  // Örnek statik veri:
  return {
    'XAUUSD': { price: 2354.80, change_pct: 1.24,  direction: 'up'   },
    'EURUSD': { price: 1.0891,  change_pct: 0.31,  direction: 'up'   },
    'GBPUSD': { price: 1.2743,  change_pct: -0.18, direction: 'down' },
    'BTCUSD': { price: 68420,   change_pct: 2.87,  direction: 'up'   },
    'US500':  { price: 5204,    change_pct: 0.54,  direction: 'up'   },
    'BRENT':  { price: 88.14,   change_pct: -0.92, direction: 'down' },
    'USDTRY': { price: 32.18,   change_pct: -0.45, direction: 'down' },
  };
}

async function getAvailableSlots(preferredDate) {
  // Cal.com API entegrasyonu buraya gelecek
  return `Müsait slotlar: ${preferredDate} 10:00, 11:00, 14:00, 15:00`;
}

async function notifyAdvisor(leadId, outcome, score) {
  // Slack, SMS veya e-posta bildirimi
  console.log(`[HOT LEAD] ID: ${leadId} · Outcome: ${outcome} · Skor: ${score}`);
  // await sendSlackMessage(...)
}

function detectOutcome(transcript, analysis) {
  const t = (transcript + ' ' + (analysis?.summary ?? '')).toLowerCase();
  if (t.includes('hesap aç') || t.includes('kayıt ol'))   return 'account_opened';
  if (t.includes('randevu') || t.includes('toplantı'))     return 'appointment';
  if (t.includes('geri ara') || t.includes('sonra ara'))   return 'callback';
  if (t.includes('ilgilenmiyorum') || t.includes('hayır')) return 'not_interested';
  return 'info_given';
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// -----------------------------------------------
// MANUEL TETİKLEME (Test için)
// -----------------------------------------------
app.post('/admin/fetch-market', async (req, res) => {
  await fetchAndSaveMarketAnalysis();
  res.json({ ok: true, message: 'Piyasa analizi güncellendi' });
});

app.get('/admin/todays-analysis', async (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('daily_analysis')
    .select('*')
    .eq('analysis_date', today)
    .single();
  res.json(data ?? { error: 'Bugün analiz yok' });
});

// -----------------------------------------------
// BAŞLAT
// -----------------------------------------------
const PORT = process.env.PORT ?? 3000;
app.listen(PORT, () => {
  console.log(`[Server] http://localhost:${PORT} çalışıyor`);
  // İlk başlatmada analiz yoksa çek
  fetchAndSaveMarketAnalysis().catch(console.error);
});
