-- ============================================================
-- TRADEBOT AI CALL CENTER - SUPABASE SCHEMA
-- ============================================================

-- LEADS TABLOSU
create table if not exists leads (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  phone           text unique not null,
  email           text,
  city            text,
  age             int,
  income_level    text check (income_level in ('low','medium','high','unknown')) default 'unknown',
  interest        text[],              -- ['gold','forex','crypto','cfd','stocks']
  source          text,                -- 'csv_import' | 'web_form' | 'inbound' | 'referral'
  score           int default 0,       -- 0-100 sıcaklık skoru
  status          text check (status in ('cold','warm','hot','converted','do_not_call')) default 'cold',
  last_called_at  timestamptz,
  call_count      int default 0,
  notes           text,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- CALL LOGS TABLOSU
create table if not exists call_logs (
  id              uuid primary key default gen_random_uuid(),
  lead_id         uuid references leads(id) on delete set null,
  vapi_call_id    text unique,
  direction       text check (direction in ('inbound','outbound')) not null,
  phone_from      text,
  phone_to        text,
  duration_sec    int default 0,
  transcript      text,
  summary         text,                -- AI tarafından üretilen özet
  outcome         text check (outcome in (
                    'appointment_created',
                    'account_opened',
                    'callback_requested',
                    'info_given',
                    'not_interested',
                    'no_answer',
                    'transferred',
                    'unknown'
                  )) default 'unknown',
  market_context  jsonb,               -- O anki piyasa verileri snapshot
  recording_url   text,
  created_at      timestamptz default now()
);

-- APPOINTMENTS TABLOSU
create table if not exists appointments (
  id              uuid primary key default gen_random_uuid(),
  lead_id         uuid references leads(id) on delete cascade,
  call_log_id     uuid references call_logs(id) on delete set null,
  scheduled_at    timestamptz not null,
  duration_min    int default 30,
  advisor_name    text,
  subject         text,                -- 'demo_account' | 'investment_plan' | 'follow_up'
  status          text check (status in ('scheduled','confirmed','completed','cancelled','no_show')) default 'scheduled',
  notes           text,
  created_at      timestamptz default now()
);

-- DAILY MARKET ANALYSIS TABLOSU (Ajanın bilgi tabanı)
create table if not exists daily_analysis (
  id              uuid primary key default gen_random_uuid(),
  analysis_date   date not null unique,
  markets         jsonb not null,      -- { symbol: { price, change_pct, direction } }
  ai_summary      text not null,       -- AI tarafından üretilen satış odaklı özet
  sales_scripts   jsonb,               -- { gold: "script...", crypto: "script..." }
  objection_tips  jsonb,               -- Günün piyasasına özel itiraz karşılama
  key_events      text[],              -- ['Fed kararı 16:00', 'CPI verisi']
  sentiment       text check (sentiment in ('bullish','bearish','neutral','volatile')) default 'neutral',
  created_at      timestamptz default now()
);

-- OUTBOUND CAMPAIGNS TABLOSU
create table if not exists campaigns (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  status          text check (status in ('draft','active','paused','completed')) default 'draft',
  target_filter   jsonb,               -- { status: 'cold', interest: ['gold'], city: 'Istanbul' }
  total_leads     int default 0,
  called          int default 0,
  converted       int default 0,
  scheduled_at    timestamptz,
  completed_at    timestamptz,
  created_at      timestamptz default now()
);

-- ============================================================
-- INDEXES
-- ============================================================
create index if not exists idx_leads_status    on leads(status);
create index if not exists idx_leads_score     on leads(score desc);
create index if not exists idx_leads_phone     on leads(phone);
create index if not exists idx_calls_lead      on call_logs(lead_id);
create index if not exists idx_calls_date      on call_logs(created_at desc);
create index if not exists idx_analysis_date   on daily_analysis(analysis_date desc);

-- ============================================================
-- AUTO UPDATE updated_at
-- ============================================================
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger leads_updated_at
  before update on leads
  for each row execute function update_updated_at();

-- ============================================================
-- SCORE HESAPLAMA FONKSİYONU
-- ============================================================
create or replace function calculate_lead_score(lead_id uuid)
returns int as $$
declare
  v_score int := 0;
  v_call_count int;
  v_last_outcome text;
  v_interest text[];
begin
  select call_count, interest into v_call_count, v_interest
  from leads where id = lead_id;

  select outcome into v_last_outcome
  from call_logs
  where call_logs.lead_id = calculate_lead_score.lead_id
  order by created_at desc limit 1;

  -- Temel skor
  if v_last_outcome = 'callback_requested' then v_score := v_score + 40; end if;
  if v_last_outcome = 'info_given'         then v_score := v_score + 25; end if;
  if v_last_outcome = 'appointment_created' then v_score := v_score + 80; end if;
  if v_last_outcome = 'not_interested'     then v_score := v_score - 20; end if;
  if v_last_outcome = 'no_answer'          then v_score := v_score + 5;  end if;

  -- Arama sayısına göre
  if v_call_count between 1 and 3 then v_score := v_score + 10; end if;
  if v_call_count > 5              then v_score := v_score - 10; end if;

  -- İlgi alanına göre bonus
  if 'gold' = any(v_interest) or 'crypto' = any(v_interest) then
    v_score := v_score + 15;
  end if;

  return greatest(0, least(100, v_score));
end;
$$ language plpgsql;

-- ============================================================
-- ÖRNEK TEST VERİSİ
-- ============================================================
insert into leads (name, phone, city, interest, source, score, status) values
  ('Ahmet Kaya',    '+905321234567', 'İstanbul', array['gold','forex'],  'csv_import', 92, 'hot'),
  ('Fatma Demir',   '+905551234567', 'İzmir',    array['crypto','cfd'],  'web_form',   88, 'hot'),
  ('Mehmet Balcı',  '+905061234567', 'Ankara',   array['cfd','gold'],    'csv_import', 72, 'warm'),
  ('Hasan Yılmaz',  '+905441234567', 'Bursa',    array['stocks'],        'csv_import', 35, 'cold'),
  ('Zeynep Arslan', '+905321234568', 'İstanbul', array['crypto'],        'inbound',    60, 'warm')
on conflict (phone) do nothing;
