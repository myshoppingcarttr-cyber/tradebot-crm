// ============================================================
// TRADEBOT - ANA WEBHOOK SUNUCUSU
// Vapi.ai'dan gelen tüm olayları karşılar
// ============================================================

const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const crypto = require('crypto');
require('dotenv').config();

const app = express();
app.use(express.json());

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// ============================================================
// VAPI WEBHOOK — Ana endpoint
// ============================================================
app.post('/webhook/vapi', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'No message' });

  console.log(`[VAPI] Event: ${message.type} | Call: ${message.call?.id}`);

  try {
    switch (message.type) {

      // Aramanın başlangıcında çağrılır
      case 'call-started':
        await handleCallStarted(message);
        break;

      // Ajan bir tool çağırdığında
      case 'tool-calls':
        const toolResult = await handleToolCall(message);
        return res.json(toolResult);

      // Arama bittiğinde — transkript + sonuç
      case 'end-of-call-report':
        await handleCallEnded(message);
        break;

      default:
        console.log(`[VAPI] Unhandled event: ${message.type}`);
    }

    res.json({ received: true });

  } catch (err) {
    console.error('[VAPI] Webhook error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// ARAMANIN BAŞLANGIÇI — Müşteriyi bul veya oluştur
// ============================================================
async function handleCallStarted(message) {
  const { call } = message;
  const phone = call.direction === 'inbound'
    ? call.customer?.number
    : call.phoneNumber?.number;

  if (!phone) return;

  // Lead var mı?
  let { data: lead } = await supabase
    .from('leads')
    .select('*')
    .eq('phone', phone)
    .single();

  // Yoksa oluştur
  if (!lead) {
    const { data: newLead } = await supabase
      .from('leads')
      .insert({ phone, source: call.direction === 'inbound' ? 'inbound' : 'outbound' })
      .select()
      .single();
    lead = newLead;
  }

  // Call log başlat
  await supabase.from('call_logs').insert({
    lead_id:     lead?.id,
    vapi_call_id: call.id,
    direction:   call.direction,
    phone_from:  call.direction === 'inbound' ? phone : process.env.TWILIO_PHONE_NUMBER,
    phone_to:    call.direction === 'outbound' ? phone : process.env.TWILIO_PHONE_NUMBER,
    outcome:     'unknown'
  });

  console.log(`[CALL STARTED] ${call.direction.toUpperCase()} | Lead: ${lead?.name || phone}`);
}

// ============================================================
// TOOL CALL HANDLER — Ajanın çağırdığı fonksiyonlar
// ============================================================
async function handleToolCall(message) {
  const { toolCallList } = message;
  const results = [];

  for (const tool of toolCallList) {
    console.log(`[TOOL] ${tool.function.name}`, tool.function.arguments);

    let result;
    switch (tool.function.name) {

      case 'get_market_data':
        result = await getMarketData();
        break;

      case 'save_lead':
        result = await saveLead(tool.function.arguments);
        break;

      case 'update_lead_status':
        result = await updateLeadStatus(tool.function.arguments);
        break;

      case 'create_appointment':
        result = await createAppointment(tool.function.arguments);
        break;

      case 'get_lead_info':
        result = await getLeadInfo(tool.function.arguments);
        break;

      default:
        result = { error: `Unknown tool: ${tool.function.name}` };
    }

    results.push({ toolCallId: tool.id, result: JSON.stringify(result) });
  }

  return { results };
}

// ============================================================
// TOOL: Günlük piyasa verisini getir
// ============================================================
async function getMarketData() {
  const today = new Date().toISOString().split('T')[0];

  const { data } = await supabase
    .from('daily_analysis')
    .select('*')
    .eq('analysis_date', today)
    .single();

  if (!data) {
    return { error: 'Bugün için analiz henüz hazır değil.' };
  }

  return {
    summary:      data.ai_summary,
    markets:      data.markets,
    key_events:   data.key_events,
    sentiment:    data.sentiment,
    sales_scripts: data.sales_scripts
  };
}

// ============================================================
// TOOL: Lead kaydet / güncelle
// ============================================================
async function saveLead({ phone, name, email, city, interest, notes }) {
  const { data: existing } = await supabase
    .from('leads')
    .select('id')
    .eq('phone', phone)
    .single();

  if (existing) {
    await supabase.from('leads').update({
      name:     name || undefined,
      email:    email || undefined,
      city:     city || undefined,
      interest: interest ? [interest] : undefined,
      notes:    notes || undefined,
      updated_at: new Date().toISOString()
    }).eq('id', existing.id);

    return { success: true, action: 'updated', lead_id: existing.id };
  }

  const { data: newLead } = await supabase.from('leads').insert({
    phone, name, email, city,
    interest: interest ? [interest] : [],
    notes,
    source: 'inbound'
  }).select('id').single();

  return { success: true, action: 'created', lead_id: newLead.id };
}

// ============================================================
// TOOL: Lead durumunu güncelle (sıcaklık skoru)
// ============================================================
async function updateLeadStatus({ phone, status, score, notes }) {
  const { data: lead } = await supabase
    .from('leads')
    .select('id, call_count')
    .eq('phone', phone)
    .single();

  if (!lead) return { error: 'Lead bulunamadı' };

  await supabase.from('leads').update({
    status:       status || undefined,
    score:        score || undefined,
    notes:        notes || undefined,
    call_count:   (lead.call_count || 0) + 1,
    last_called_at: new Date().toISOString()
  }).eq('id', lead.id);

  return { success: true, new_status: status, new_score: score };
}

// ============================================================
// TOOL: Randevu oluştur
// ============================================================
async function createAppointment({ phone, date_time, subject, advisor_name }) {
  const { data: lead } = await supabase
    .from('leads')
    .select('id, name')
    .eq('phone', phone)
    .single();

  if (!lead) return { error: 'Lead bulunamadı, önce kaydet.' };

  const { data: appointment } = await supabase
    .from('appointments')
    .insert({
      lead_id:      lead.id,
      scheduled_at: new Date(date_time).toISOString(),
      subject:      subject || 'demo_account',
      advisor_name: advisor_name || 'Uzman Danışman',
      status:       'scheduled'
    })
    .select()
    .single();

  // Lead'i sıcak yap
  await supabase.from('leads').update({
    status: 'hot',
    score:  90
  }).eq('id', lead.id);

  return {
    success: true,
    appointment_id: appointment.id,
    message: `Randevunuz oluşturuldu: ${date_time}`
  };
}

// ============================================================
// TOOL: Lead bilgisini getir (arama öncesi context)
// ============================================================
async function getLeadInfo({ phone }) {
  const { data: lead } = await supabase
    .from('leads')
    .select('*')
    .eq('phone', phone)
    .single();

  if (!lead) return { found: false };

  // Son arama transkriptini de getir
  const { data: lastCall } = await supabase
    .from('call_logs')
    .select('summary, outcome, created_at')
    .eq('lead_id', lead.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();

  return {
    found:       true,
    name:        lead.name,
    city:        lead.city,
    interest:    lead.interest,
    status:      lead.status,
    call_count:  lead.call_count,
    last_call:   lastCall || null,
    notes:       lead.notes
  };
}

// ============================================================
// ARAMANIN SONU — Transkript ve sonuç kaydet
// ============================================================
async function handleCallEnded(message) {
  const { call, transcript, summary, recordingUrl } = message;

  // Outcome belirle (transcript analizi)
  const outcome = detectOutcome(transcript || '');

  // Call log güncelle
  await supabase.from('call_logs')
    .update({
      transcript:    transcript || '',
      summary:       summary || '',
      duration_sec:  Math.round((call.endedAt - call.startedAt) / 1000) || 0,
      outcome:       outcome,
      recording_url: recordingUrl || null
    })
    .eq('vapi_call_id', call.id);

  // Lead skoru güncelle
  const scoreMap = {
    appointment_created: 90,
    account_opened:      100,
    callback_requested:  65,
    info_given:          35,
    not_interested:      10,
    no_answer:           20,
    transferred:         70
  };

  const statusMap = {
    appointment_created: 'hot',
    account_opened:      'converted',
    callback_requested:  'warm',
    info_given:          'warm',
    not_interested:      'cold',
    no_answer:           'cold',
    transferred:         'hot'
  };

  const { data: callLog } = await supabase
    .from('call_logs')
    .select('lead_id')
    .eq('vapi_call_id', call.id)
    .single();

  if (callLog?.lead_id) {
    await supabase.from('leads').update({
      score:          scoreMap[outcome] || 20,
      status:         statusMap[outcome] || 'cold',
      last_called_at: new Date().toISOString()
    }).eq('id', callLog.lead_id);
  }

  console.log(`[CALL ENDED] ${call.id} | Outcome: ${outcome} | Duration: ${Math.round((call.endedAt - call.startedAt) / 1000)}sn`);
}

// ============================================================
// TRANSCRIPT'TEN SONUCU ÇIKAR
// ============================================================
function detectOutcome(transcript) {
  const t = transcript.toLowerCase();
  if (t.includes('randevu') && (t.includes('tamam') || t.includes('oluştur'))) return 'appointment_created';
  if (t.includes('hesap aç') || t.includes('kayıt ol'))                        return 'account_opened';
  if (t.includes('geri arayın') || t.includes('sonra konuşalım'))               return 'callback_requested';
  if (t.includes('ilgilenmiyorum') || t.includes('istemiyorum'))                return 'not_interested';
  if (t.includes('danışman') || t.includes('bağlayın'))                        return 'transferred';
  if (t.includes('tamam') || t.includes('anlıyorum'))                          return 'info_given';
  return 'unknown';
}

// ============================================================
// HEALTH CHECK
// ============================================================
app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`[SERVER] TradebotCRM webhook running on port ${PORT}`));

module.exports = app;
