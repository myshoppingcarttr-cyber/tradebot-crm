import { useState, useEffect, useRef } from "react";

const COLORS = {
  bg: "#0A0C10",
  surface: "#0F1318",
  card: "#141820",
  border: "#1E2530",
  accent: "#F0B429",
  accentDim: "#F0B42920",
  green: "#22C55E",
  red: "#EF4444",
  blue: "#3B82F6",
  purple: "#8B5CF6",
  text: "#E8EDF5",
  muted: "#6B7A8D",
  subtle: "#2A3240",
};

const mockLeads = [
  { id: 1, name: "Ahmet Yılmaz", phone: "+90 532 xxx xx01", status: "sıcak", score: 87, lastCall: "14:32", product: "Gold CFD", note: "Altın yatırımına ilgi duyuyor" },
  { id: 2, name: "Mehmet Kara", phone: "+90 544 xxx xx02", status: "ılık", score: 62, lastCall: "13:15", product: "EUR/USD", note: "Daha önce forex denemiş" },
  { id: 3, name: "Ayşe Demir", phone: "+90 555 xxx xx03", status: "soğuk", score: 23, lastCall: "11:40", product: "BTC/USD", note: "Şu an ilgilenmiyor" },
  { id: 4, name: "Fatma Çelik", phone: "+90 506 xxx xx04", status: "hazır", score: 95, lastCall: "15:10", product: "S&P 500", note: "Hesap açmaya hazır" },
  { id: 5, name: "Ali Öztürk", phone: "+90 532 xxx xx05", status: "sıcak", score: 78, lastCall: "12:55", product: "Gold CFD", note: "Demo hesap istedi" },
  { id: 6, name: "Zeynep Arslan", phone: "+90 544 xxx xx06", status: "ılık", score: 55, lastCall: "10:20", product: "EUR/USD", note: "Bilgi almak istiyor" },
];

const marketData = [
  { symbol: "XAU/USD", name: "Altın", price: "2,387.45", change: "+1.24%", dir: "up", analysis: "Fed faiz kararı beklentisiyle güçlü alım baskısı. 2,400 direnç kırılırsa 2,450 hedef." },
  { symbol: "EUR/USD", name: "Euro/Dolar", price: "1.0842", change: "-0.31%", dir: "down", analysis: "ECB'nin şahin açıklamaları eurodaki baskıyı artırdı. 1.0800 destek kritik." },
  { symbol: "BTC/USD", name: "Bitcoin", price: "83,240", change: "+2.87%", dir: "up", analysis: "ETF girişleri yeniden ivmelendi. 85,000 üzerinde kapanış bullish sinyali." },
  { symbol: "S&P 500", name: "S&P 500", price: "5,612.30", change: "+0.54%", dir: "up", analysis: "Tech sektörü liderliğinde yükseliş. Kazanç sezonu beklentileri olumlu." },
  { symbol: "WTI", name: "Ham Petrol", price: "84.72", change: "-0.88%", dir: "down", analysis: "OPEC+ toplantısı öncesi belirsizlik. 83 desteği test ediliyor." },
  { symbol: "GBP/USD", name: "Sterlin/Dolar", price: "1.2634", change: "+0.17%", dir: "up", analysis: "UK enflasyon verisi beklenti üzerinde. BoE sıkılaştırma baskısı devam ediyor." },
];

const callLogs = [
  { id: 1, name: "Ahmet Yılmaz", duration: "3:42", outcome: "Randevu", time: "15:10", sentiment: "olumlu" },
  { id: 2, name: "Burak Şahin", duration: "1:15", outcome: "İlgilenmedi", time: "14:55", sentiment: "olumsuz" },
  { id: 3, name: "Ceren Aydın", duration: "5:20", outcome: "Demo Hesap", time: "14:30", sentiment: "olumlu" },
  { id: 4, name: "Deniz Koç", duration: "2:08", outcome: "Geri Arama", time: "14:12", sentiment: "nötr" },
  { id: 5, name: "Emre Yıldız", duration: "4:55", outcome: "Hesap Açtı", time: "13:45", sentiment: "olumlu" },
];

const statusColors = {
  "hazır": { bg: "#22C55E20", text: "#22C55E", dot: "#22C55E" },
  "sıcak": { bg: "#F0B42920", text: "#F0B429", dot: "#F0B429" },
  "ılık": { bg: "#3B82F620", text: "#3B82F6", dot: "#3B82F6" },
  "soğuk": { bg: "#6B7A8D20", text: "#6B7A8D", dot: "#6B7A8D" },
};

const outcomeColors = {
  "Hesap Açtı": "#22C55E",
  "Demo Hesap": "#F0B429",
  "Randevu": "#3B82F6",
  "Geri Arama": "#8B5CF6",
  "İlgilenmedi": "#6B7A8D",
};

// Animated number
function AnimatedStat({ value, suffix = "", prefix = "" }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const num = parseFloat(String(value).replace(/,/g, ""));
    let start = 0;
    const step = num / 40;
    const timer = setInterval(() => {
      start += step;
      if (start >= num) { setDisplay(num); clearInterval(timer); }
      else setDisplay(Math.floor(start));
    }, 20);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{prefix}{display.toLocaleString()}{suffix}</span>;
}

// Score bar
function ScoreBar({ score }) {
  const color = score >= 80 ? COLORS.green : score >= 50 ? COLORS.accent : COLORS.muted;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ flex: 1, height: 4, background: COLORS.subtle, borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${score}%`, height: "100%", background: color, borderRadius: 2, transition: "width 0.8s ease" }} />
      </div>
      <span style={{ fontSize: 11, color, fontWeight: 700, minWidth: 28 }}>{score}</span>
    </div>
  );
}

// Pulse dot
function PulseDot({ color }) {
  return (
    <span style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", width: 10, height: 10 }}>
      <span style={{
        position: "absolute", width: 10, height: 10, borderRadius: "50%",
        background: color, opacity: 0.3,
        animation: "pulse 2s ease-out infinite"
      }} />
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: color }} />
    </span>
  );
}

export default function ForexCallCenter() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedLead, setSelectedLead] = useState(null);
  const [agentActive, setAgentActive] = useState(false);
  const [callCount, setCallCount] = useState(0);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [dailyAnalysis, setDailyAnalysis] = useState("");
  const [agentScript, setAgentScript] = useState("");
  const [scriptLoading, setScriptLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", text: "Merhaba! Ben ARIA, AI satış asistanınızım. Günlük piyasa analizini yüklememi ister misiniz?" }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    if (agentActive) {
      const interval = setInterval(() => setCallCount(c => c + 1), 3000);
      return () => clearInterval(interval);
    }
  }, [agentActive]);

  async function generateDailyAnalysis() {
    setAnalysisLoading(true);
    setDailyAnalysis("");
    const marketSummary = marketData.map(m => `${m.symbol}: ${m.price} (${m.change}) - ${m.analysis}`).join("\n");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `Sen profesyonel bir finansal analist ve forex satış uzmanısın. 
Görevin: Günlük piyasa verilerini kullanarak, forex satış temsilcilerinin müşterileri ikna etmesine yardımcı olacak 
SATIŞ ODAKLI bir piyasa analizi yazmak. 
Dil: Türkçe. Ton: Güven verici, aciliyet hissi yaratan, fırsat vurgulayan.
Format: Kısa paragraflar, net mesajlar, satış cümleleriyle bitir.`,
          messages: [{
            role: "user",
            content: `Bugünün piyasa verileri:\n${marketSummary}\n\nBu verilere dayanarak satış temsilcilerimizin bugün müşterilere kullanabileceği, ikna edici ve fırsat odaklı günlük piyasa analizi yaz. Her enstrüman için neden ŞIMDI fırsat olduğunu vurgula.`
          }]
        })
      });
      const data = await res.json();
      setDailyAnalysis(data.content?.[0]?.text || "Analiz alınamadı.");
    } catch (e) {
      setDailyAnalysis("Bağlantı hatası. Lütfen tekrar deneyin.");
    }
    setAnalysisLoading(false);
  }

  async function generateAgentScript(lead) {
    setScriptLoading(true);
    setAgentScript("");
    const mkt = marketData.slice(0, 3).map(m => `${m.symbol}: ${m.change}`).join(", ");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 800,
          system: `Sen deneyimli bir forex satış uzmanısın. 
Müşteri profiline ve günlük piyasa verilerine göre kişiselleştirilmiş satış scripti yazıyorsun.
Dil: Türkçe. Format: Açılış → İhtiyaç tespiti → Fırsat sunumu → İtiraz karşılama → Kapanış
Her bölümü kısa ve net tut. Gerçek piyasa verilerini konuşmaya entegre et.`,
          messages: [{
            role: "user",
            content: `Müşteri: ${lead.name}
İlgilendiği ürün: ${lead.product}
Sıcaklık skoru: ${lead.score}/100
Not: ${lead.note}
Güncel piyasa: ${mkt}

Bu müşteri için kişiselleştirilmiş outbound arama scripti yaz.`
          }]
        })
      });
      const data = await res.json();
      setAgentScript(data.content?.[0]?.text || "Script oluşturulamadı.");
    } catch (e) {
      setAgentScript("Bağlantı hatası.");
    }
    setScriptLoading(false);
  }

  async function sendChat(msg) {
    if (!msg.trim()) return;
    const newMessages = [...chatMessages, { role: "user", text: msg }];
    setChatMessages(newMessages);
    setChatInput("");
    setChatLoading(true);
    const mktContext = marketData.map(m => `${m.symbol}: ${m.price} ${m.change} - ${m.analysis}`).join("\n");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 600,
          system: `Sen ARIA - yapay zeka forex satış asistanısın. 
Satış temsilcilerine günlük piyasa analizi, satış stratejisi ve müşteri ikna teknikleri konusunda yardım ediyorsun.
Güncel piyasa verileri:\n${mktContext}
Dil: Türkçe. Kısa, net, aksiyon odaklı yanıtlar ver.`,
          messages: newMessages.map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text }))
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Yanıt alınamadı.";
      setChatMessages(prev => [...prev, { role: "assistant", text: reply }]);
    } catch (e) {
      setChatMessages(prev => [...prev, { role: "assistant", text: "Bağlantı hatası." }]);
    }
    setChatLoading(false);
  }

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "◈" },
    { id: "leads", label: "Lead CRM", icon: "◉" },
    { id: "market", label: "Piyasa", icon: "◆" },
    { id: "agent", label: "AI Ajan", icon: "◎" },
    { id: "aria", label: "ARIA", icon: "✦" },
  ];

  return (
    <div style={{ fontFamily: "'DM Mono', 'Courier New', monospace", background: COLORS.bg, minHeight: "100vh", color: COLORS.text }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Syne:wght@400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #2A3240; border-radius: 2px; }
        @keyframes pulse { 0%,100%{transform:scale(1);opacity:0.3} 50%{transform:scale(2.5);opacity:0} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        .tab-btn:hover { background: #1E2530 !important; }
        .lead-row:hover { background: #141820 !important; cursor: pointer; }
        .action-btn:hover { opacity: 0.8; transform: translateY(-1px); }
        .market-card:hover { border-color: #F0B42940 !important; }
      `}</style>

      {/* Header */}
      <div style={{ borderBottom: `1px solid ${COLORS.border}`, padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 56 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 32, height: 32, background: `linear-gradient(135deg, ${COLORS.accent}, #D97706)`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: "#000" }}>A</div>
          <div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, letterSpacing: "0.05em" }}>APEX<span style={{ color: COLORS.accent }}>CALL</span></div>
            <div style={{ fontSize: 9, color: COLORS.muted, letterSpacing: "0.1em" }}>AI FOREX CALL CENTER</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: COLORS.muted }}>
            <PulseDot color={COLORS.green} />
            <span>Sistem Aktif</span>
          </div>
          <div style={{ fontSize: 11, color: COLORS.muted }}>
            {new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" })}
          </div>
        </div>
      </div>

      {/* Nav */}
      <div style={{ borderBottom: `1px solid ${COLORS.border}`, padding: "0 24px", display: "flex", gap: 4 }}>
        {tabs.map(t => (
          <button key={t.id} className="tab-btn"
            onClick={() => setActiveTab(t.id)}
            style={{
              padding: "12px 16px", background: "transparent", border: "none", cursor: "pointer",
              color: activeTab === t.id ? COLORS.accent : COLORS.muted,
              borderBottom: activeTab === t.id ? `2px solid ${COLORS.accent}` : "2px solid transparent",
              fontSize: 12, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 6,
              transition: "all 0.2s", marginBottom: -1,
            }}>
            <span>{t.icon}</span>{t.label}
          </button>
        ))}
      </div>

      <div style={{ padding: 24 }}>

        {/* DASHBOARD */}
        {activeTab === "dashboard" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
              {[
                { label: "Bugün Arama", value: 342 + callCount, icon: "📞", color: COLORS.blue, change: "+12%" },
                { label: "Sıcak Lead", value: 47, icon: "🔥", color: COLORS.accent, change: "+8%" },
                { label: "Dönüşüm", value: "14.2", suffix: "%", icon: "◈", color: COLORS.green, change: "+2.1%" },
                { label: "Açılan Hesap", value: 8, icon: "✓", color: COLORS.purple, change: "Bugün" },
              ].map((s, i) => (
                <div key={i} style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                    <span style={{ fontSize: 18 }}>{s.icon}</span>
                    <span style={{ fontSize: 10, color: COLORS.green, background: "#22C55E15", padding: "2px 8px", borderRadius: 20 }}>{s.change}</span>
                  </div>
                  <div style={{ fontSize: 28, fontWeight: 700, color: s.color, fontFamily: "'Syne', sans-serif" }}>
                    <AnimatedStat value={s.value} suffix={s.suffix || ""} />
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Agent Control */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>
              <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16, color: COLORS.accent }}>◎ OUTBOUND AJAN KONTROLÜ</div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                  <PulseDot color={agentActive ? COLORS.green : COLORS.muted} />
                  <span style={{ fontSize: 12, color: agentActive ? COLORS.green : COLORS.muted }}>
                    {agentActive ? `Aktif — ${callCount} arama yapıldı` : "Pasif"}
                  </span>
                </div>
                {[
                  { label: "Liste", value: "Lead Havuzu A (284 kişi)" },
                  { label: "Ürün", value: "Gold CFD + EUR/USD" },
                  { label: "Günlük Limit", value: "500 arama" },
                  { label: "Çalışma Saati", value: "09:00 – 20:00" },
                ].map((r, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 11, padding: "6px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                    <span style={{ color: COLORS.muted }}>{r.label}</span>
                    <span style={{ color: COLORS.text }}>{r.value}</span>
                  </div>
                ))}
                <button
                  className="action-btn"
                  onClick={() => setAgentActive(!agentActive)}
                  style={{
                    marginTop: 16, width: "100%", padding: "10px 0",
                    background: agentActive ? "#EF444420" : `linear-gradient(135deg, ${COLORS.accent}, #D97706)`,
                    border: agentActive ? `1px solid #EF4444` : "none",
                    borderRadius: 8, color: agentActive ? "#EF4444" : "#000",
                    fontWeight: 700, fontSize: 12, cursor: "pointer",
                    fontFamily: "inherit", transition: "all 0.2s",
                  }}>
                  {agentActive ? "⬛ DURAKSIT" : "▶ KAMPANYAYI BAŞLAT"}
                </button>
              </div>

              {/* Recent Calls */}
              <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16, color: COLORS.accent }}>◈ SON ARAMALAR</div>
                {callLogs.map((c, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 0", borderBottom: i < callLogs.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 28, height: 28, borderRadius: "50%", background: COLORS.subtle, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: COLORS.muted }}>
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 500 }}>{c.name}</div>
                        <div style={{ fontSize: 10, color: COLORS.muted }}>{c.time} · {c.duration}</div>
                      </div>
                    </div>
                    <span style={{ fontSize: 10, padding: "3px 8px", borderRadius: 20, background: `${outcomeColors[c.outcome]}20`, color: outcomeColors[c.outcome] }}>
                      {c.outcome}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Mini */}
            <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16, color: COLORS.accent }}>◆ CANLI PİYASA ÖZET</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12 }}>
                {marketData.map((m, i) => (
                  <div key={i} style={{ textAlign: "center", padding: "12px 8px", background: COLORS.surface, borderRadius: 8, border: `1px solid ${COLORS.border}` }}>
                    <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 4 }}>{m.symbol}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.text }}>{m.price}</div>
                    <div style={{ fontSize: 11, color: m.dir === "up" ? COLORS.green : COLORS.red, marginTop: 2 }}>{m.change}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* LEADS CRM */}
        {activeTab === "leads" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18 }}>Lead CRM</div>
                <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>284 kayıt · 47 sıcak · 8 hazır</div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                {["Tümü", "Hazır", "Sıcak", "Ilık", "Soğuk"].map((f, i) => (
                  <button key={i} style={{ padding: "6px 14px", background: i === 0 ? COLORS.accent : COLORS.surface, color: i === 0 ? "#000" : COLORS.muted, border: `1px solid ${COLORS.border}`, borderRadius: 6, fontSize: 11, cursor: "pointer", fontFamily: "inherit" }}>
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: selectedLead ? "1fr 380px" : "1fr", gap: 16 }}>
              <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: "hidden" }}>
                <div style={{ display: "grid", gridTemplateColumns: "2fr 1.5fr 1fr 1.5fr 1fr 120px", padding: "10px 16px", borderBottom: `1px solid ${COLORS.border}`, fontSize: 10, color: COLORS.muted, letterSpacing: "0.08em" }}>
                  <span>MÜŞTERİ</span><span>TELEFON</span><span>SKOR</span><span>ÜRÜN</span><span>SON ARAMA</span><span>DURUM</span>
                </div>
                {mockLeads.map((lead) => (
                  <div key={lead.id} className="lead-row"
                    onClick={() => setSelectedLead(selectedLead?.id === lead.id ? null : lead)}
                    style={{
                      display: "grid", gridTemplateColumns: "2fr 1.5fr 1fr 1.5fr 1fr 120px",
                      padding: "12px 16px", borderBottom: `1px solid ${COLORS.border}`,
                      background: selectedLead?.id === lead.id ? COLORS.subtle : "transparent",
                      transition: "background 0.15s",
                    }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 30, height: 30, borderRadius: "50%", background: `linear-gradient(135deg, ${COLORS.accent}30, ${COLORS.purple}30)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: COLORS.accent }}>
                        {lead.name.split(" ").map(n => n[0]).join("")}
                      </div>
                      <span style={{ fontSize: 13 }}>{lead.name}</span>
                    </div>
                    <span style={{ fontSize: 12, color: COLORS.muted, alignSelf: "center" }}>{lead.phone}</span>
                    <div style={{ alignSelf: "center" }}><ScoreBar score={lead.score} /></div>
                    <span style={{ fontSize: 12, alignSelf: "center" }}>{lead.product}</span>
                    <span style={{ fontSize: 12, color: COLORS.muted, alignSelf: "center" }}>{lead.lastCall}</span>
                    <div style={{ alignSelf: "center" }}>
                      <span style={{ fontSize: 10, padding: "3px 10px", borderRadius: 20, background: statusColors[lead.status]?.bg, color: statusColors[lead.status]?.text }}>
                        {lead.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {selectedLead && (
                <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20, animation: "fadeIn 0.2s ease" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
                    <div>
                      <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 16 }}>{selectedLead.name}</div>
                      <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>{selectedLead.phone}</div>
                    </div>
                    <span style={{ fontSize: 10, padding: "4px 10px", borderRadius: 20, background: statusColors[selectedLead.status]?.bg, color: statusColors[selectedLead.status]?.text }}>
                      {selectedLead.status}
                    </span>
                  </div>

                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 6 }}>İKNA SKORU</div>
                    <ScoreBar score={selectedLead.score} />
                  </div>

                  <div style={{ background: COLORS.surface, borderRadius: 8, padding: 12, marginBottom: 16 }}>
                    <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 4 }}>NOT</div>
                    <div style={{ fontSize: 12 }}>{selectedLead.note}</div>
                  </div>

                  <button
                    className="action-btn"
                    onClick={() => generateAgentScript(selectedLead)}
                    disabled={scriptLoading}
                    style={{
                      width: "100%", padding: "10px 0", marginBottom: 8,
                      background: `linear-gradient(135deg, ${COLORS.accent}, #D97706)`,
                      border: "none", borderRadius: 8, color: "#000",
                      fontWeight: 700, fontSize: 12, cursor: scriptLoading ? "wait" : "pointer",
                      fontFamily: "inherit", transition: "all 0.2s", opacity: scriptLoading ? 0.7 : 1,
                    }}>
                    {scriptLoading ? "⟳ SCRIPT OLUŞTURULUYOR..." : "✦ AI SATIŞ SCRİPTİ OLUŞTUR"}
                  </button>

                  {agentScript && (
                    <div style={{ background: COLORS.surface, borderRadius: 8, padding: 12, maxHeight: 280, overflowY: "auto", animation: "fadeIn 0.3s ease" }}>
                      <div style={{ fontSize: 10, color: COLORS.accent, marginBottom: 8 }}>◈ KİŞİSEL SATIŞ SCRİPTİ</div>
                      <div style={{ fontSize: 11, lineHeight: 1.7, color: COLORS.text, whiteSpace: "pre-wrap" }}>{agentScript}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* MARKET */}
        {activeTab === "market" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18 }}>Günlük Piyasa Analizi</div>
                <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 2 }}>Satış ekibine özel ikna verileri</div>
              </div>
              <button
                className="action-btn"
                onClick={generateDailyAnalysis}
                disabled={analysisLoading}
                style={{
                  padding: "10px 20px", background: `linear-gradient(135deg, ${COLORS.accent}, #D97706)`,
                  border: "none", borderRadius: 8, color: "#000", fontWeight: 700,
                  fontSize: 12, cursor: analysisLoading ? "wait" : "pointer",
                  fontFamily: "inherit", transition: "all 0.2s", opacity: analysisLoading ? 0.7 : 1,
                }}>
                {analysisLoading ? "⟳ ANALİZ ÜRETILIYOR..." : "✦ AI ANALİZ ÜRET"}
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
              {marketData.map((m, i) => (
                <div key={i} className="market-card" style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 16, transition: "border-color 0.2s" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div>
                      <div style={{ fontSize: 10, color: COLORS.muted, letterSpacing: "0.08em" }}>{m.name}</div>
                      <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 13, color: COLORS.accent }}>{m.symbol}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 16, fontWeight: 700 }}>{m.price}</div>
                      <div style={{ fontSize: 12, color: m.dir === "up" ? COLORS.green : COLORS.red }}>{m.change}</div>
                    </div>
                  </div>
                  <div style={{ height: 1, background: COLORS.border, marginBottom: 10 }} />
                  <div style={{ fontSize: 11, color: COLORS.muted, lineHeight: 1.6 }}>{m.analysis}</div>
                </div>
              ))}
            </div>

            {dailyAnalysis && (
              <div style={{ background: COLORS.card, border: `1px solid ${COLORS.accent}40`, borderRadius: 12, padding: 24, animation: "fadeIn 0.3s ease" }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, color: COLORS.accent, marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
                  <span>✦</span> SATIŞ EKİBİ GÜNLÜK BRİFİNGİ — AI TARAFINDAN OLUŞTURULDU
                </div>
                <div style={{ fontSize: 13, lineHeight: 1.8, color: COLORS.text, whiteSpace: "pre-wrap" }}>{dailyAnalysis}</div>
              </div>
            )}
          </div>
        )}

        {/* AGENT */}
        {activeTab === "agent" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18, marginBottom: 20 }}>Vapi.ai Ajan Konfigürasyonu</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {[
                {
                  title: "INBOUND AGENT — KARŞILAyıcı",
                  color: COLORS.blue,
                  items: [
                    ["Platform", "Vapi.ai"],
                    ["Model", "Claude Sonnet"],
                    ["TTS Sesi", "ElevenLabs TR-Male"],
                    ["Telefon", "Twilio +90 212 XXX XX XX"],
                    ["Çalışma", "7/24 Aktif"],
                    ["Webhook", "api.apexcall.com/inbound"],
                  ],
                  tools: ["check_availability", "create_appointment", "save_lead", "get_product_info"],
                },
                {
                  title: "OUTBOUND AGENT — SATIŞ",
                  color: COLORS.accent,
                  items: [
                    ["Platform", "Vapi.ai Campaign"],
                    ["Model", "Claude Sonnet"],
                    ["TTS Sesi", "ElevenLabs TR-Male"],
                    ["Günlük Limit", "500 arama"],
                    ["Zaman", "09:00 – 20:00"],
                    ["Webhook", "api.apexcall.com/outbound"],
                  ],
                  tools: ["get_lead_info", "update_lead_status", "schedule_callback", "transfer_to_human"],
                },
              ].map((agent, i) => (
                <div key={i} style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 12, color: agent.color, marginBottom: 16 }}>◎ {agent.title}</div>
                  {agent.items.map(([k, v], j) => (
                    <div key={j} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, padding: "6px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                      <span style={{ color: COLORS.muted }}>{k}</span>
                      <span style={{ color: COLORS.text }}>{v}</span>
                    </div>
                  ))}
                  <div style={{ marginTop: 16 }}>
                    <div style={{ fontSize: 10, color: COLORS.muted, marginBottom: 8 }}>TOOLS / FONKSIYONLAR</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {agent.tools.map((t, j) => (
                        <span key={j} style={{ fontSize: 10, padding: "3px 8px", background: `${agent.color}15`, color: agent.color, borderRadius: 4, border: `1px solid ${agent.color}30` }}>
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* System Prompt Preview */}
            <div style={{ marginTop: 16, background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: 20 }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 12, color: COLORS.accent, marginBottom: 12 }}>◈ OUTBOUND AGENT SYSTEM PROMPT</div>
              <pre style={{ fontSize: 11, color: COLORS.text, lineHeight: 1.7, overflowX: "auto", background: COLORS.surface, padding: 16, borderRadius: 8, whiteSpace: "pre-wrap" }}>
{`Sen APEX CALL'un AI satış uzmanısın. Adın Alex.
Görevin: Yurt dışı forex/CFD ürünlerini tanıtmak ve hesap açılışı sağlamak.

KURAL 1: Her zaman güven ver, baskı yapma.
KURAL 2: Günlük piyasa verilerini konuşmaya entegre et.
KURAL 3: Müşteri "hayır" derse 3 farklı yaklaşım dene.
KURAL 4: Sıcak müşteriyi anında canlı danışmana aktar.

AÇILIŞ: "Merhaba {isim} bey/hanım, ben Alex arıyorum.
Bugün {ürün} piyasasında ilginç bir hareket var,
2 dakikanız olsa sesinizi duymak istiyorum..."

İTİRAZ KARŞILAMA:
- "İlgilenmiyorum" → "Anlıyorum, sadece bugünkü altın 
  hareketini paylaşmak istedim, {fiyat} seviyesinde..."
- "Param yok" → "Zaten minimum 100$ ile başlanabiliyor..."
- "Güvenmiyorum" → "Haklısınız, şeffaflık bizim önceliğimiz..."`}
              </pre>
            </div>
          </div>
        )}

        {/* ARIA CHAT */}
        {activeTab === "aria" && (
          <div style={{ animation: "fadeIn 0.3s ease", maxWidth: 720, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 24 }}>
              <div style={{ width: 56, height: 56, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple})`, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, margin: "0 auto 12px", boxShadow: `0 0 30px ${COLORS.accent}40` }}>✦</div>
              <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 20 }}>ARIA</div>
              <div style={{ fontSize: 11, color: COLORS.muted, marginTop: 4 }}>AI Satış Asistanı · Piyasa Analizi · Strateji</div>
            </div>

            <div style={{ background: COLORS.card, border: `1px solid ${COLORS.border}`, borderRadius: 12, height: 420, overflowY: "auto", padding: 20, marginBottom: 12 }}>
              {chatMessages.map((m, i) => (
                <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 12, animation: "fadeIn 0.2s ease" }}>
                  {m.role === "assistant" && (
                    <div style={{ width: 28, height: 28, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple})`, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, marginRight: 10, flexShrink: 0 }}>✦</div>
                  )}
                  <div style={{
                    maxWidth: "75%", padding: "10px 14px", borderRadius: m.role === "user" ? "12px 12px 4px 12px" : "12px 12px 12px 4px",
                    background: m.role === "user" ? `linear-gradient(135deg, ${COLORS.accent}30, ${COLORS.purple}20)` : COLORS.surface,
                    border: `1px solid ${m.role === "user" ? COLORS.accent + "40" : COLORS.border}`,
                    fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap",
                  }}>
                    {m.text}
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 28, height: 28, background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple})`, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>✦</div>
                  <div style={{ padding: "10px 14px", background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: "12px 12px 12px 4px", fontSize: 18, letterSpacing: 4, color: COLORS.muted }}>
                    <span style={{ animation: "blink 1s infinite" }}>···</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
              {["Bugün altın için satış argümanı yaz", "EUR/USD itiraz karşılama", "En sıcak lead için script"].map((s, i) => (
                <button key={i} onClick={() => sendChat(s)} style={{ padding: "6px 12px", background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 20, fontSize: 10, color: COLORS.muted, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}>
                  {s}
                </button>
              ))}
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <input
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendChat(chatInput)}
                placeholder="Piyasa analizi, satış stratejisi veya müşteri senaryosu sor..."
                style={{
                  flex: 1, padding: "12px 16px", background: COLORS.card,
                  border: `1px solid ${COLORS.border}`, borderRadius: 8,
                  color: COLORS.text, fontSize: 13, fontFamily: "inherit",
                  outline: "none",
                }}
              />
              <button
                onClick={() => sendChat(chatInput)}
                disabled={chatLoading || !chatInput.trim()}
                style={{
                  padding: "12px 20px", background: `linear-gradient(135deg, ${COLORS.accent}, #D97706)`,
                  border: "none", borderRadius: 8, color: "#000", fontWeight: 700,
                  fontSize: 13, cursor: "pointer", fontFamily: "inherit",
                  opacity: chatLoading || !chatInput.trim() ? 0.5 : 1,
                }}>
                ↑
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
