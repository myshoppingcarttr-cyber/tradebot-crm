# TradebotCRM — AI Forex Çağrı Merkezi

Vapi.ai + Claude + Supabase ile kurulu tam otomatik sesli AI satış sistemi.

---

## Mimari

```
[Supabase CRM] ←→ [Node.js Backend] ←→ [Vapi.ai Voice Agent]
                         ↑                       ↑
               [Market Analysis]         [ElevenLabs TTS]
               (Her sabah 08:00)         (Türkçe ses)
                         ↑
               [Make.com Otomasyon]
               (Outbound kampanya tetikler)
```

---

## Kurulum Adımları

### 1. Supabase

1. [supabase.com](https://supabase.com) → yeni proje oluştur
2. SQL Editor → `supabase/schema.sql` dosyasını yapıştır → Run
3. Settings → API → URL ve service_role key'i kopyala

### 2. Vapi.ai

1. [vapi.ai](https://vapi.ai) → hesap aç
2. API Keys → yeni key oluştur
3. Phone Numbers → Twilio entegrasyonu ile TR numarası al
4. Aşağıdaki komutu çalıştır:
```bash
npm run setup-vapi
```
5. Çıkan `VAPI_ASSISTANT_ID` değerini `.env` dosyasına ekle

### 3. ElevenLabs (Türkçe Ses)

1. [elevenlabs.io](https://elevenlabs.io) → hesap aç
2. Voice Library → "Turkish" filtrele → kadın ses seç
3. Voice ID'yi kopyala → `.env`'e ekle

### 4. Ortam Değişkenleri

```bash
cp config/.env.example .env
# .env dosyasını doldur
```

### 5. Backend'i Başlat

```bash
npm install
npm run dev          # geliştirme
npm start            # production
```

Backend'in dışarıdan erişilebilir olması gerekiyor.
Önerilen deployment: **Railway** veya **Render** (ücretsiz tier yeterli)

Vapi webhook URL'sini ayarla:
```
https://senin-backend.railway.app/webhook/vapi
```

### 6. Make.com Otomasyonu

Her sabah iki senaryo kur:

**Senaryo A — Günlük Analiz (08:00)**
```
Schedule (08:00) → HTTP POST /run-daily-analysis
```

**Senaryo B — Outbound Kampanya (09:00)**
```
Schedule (09:00) → HTTP POST /webhook/campaign
                   Body: { "filter": { "status": "cold" }, "maxCalls": 200 }
```

---

## Kullanım

### Manuel Outbound Kampanya
```bash
npm run campaign
```

### Günlük Analizi Manuel Tetikle
```bash
npm run analysis
```

### Tek Arama Başlat
```javascript
const { makeOutboundCall } = require('./src/vapi/setup');

await makeOutboundCall({
  phone: '+905321234567',
  leadName: 'Ahmet Bey',
  leadInterest: ['gold', 'forex']
});
```

---

## Dosya Yapısı

```
tradebot/
├── supabase/
│   └── schema.sql          ← Tüm tablolar + fonksiyonlar
├── src/
│   ├── webhooks/
│   │   └── server.js       ← Ana webhook sunucusu
│   ├── services/
│   │   └── marketAnalysis.js ← Günlük piyasa analizi
│   └── vapi/
│       └── setup.js        ← Vapi kurulum + kampanya
├── config/
│   └── .env.example
└── package.json
```

---

## Aylık Maliyet

| Servis | Plan | Maliyet |
|--------|------|---------|
| Vapi.ai | Pay-as-you-go ~$0.05/dk | ~$50-150 |
| ElevenLabs | Starter | $5 |
| Supabase | Free tier | $0 |
| Railway/Render | Free tier | $0 |
| Make.com | Free tier | $0 |
| **Toplam** | | **~$55-155/ay** |

500 arama/gün × 3dk ortalama = 1,500 dk/gün = ~$75/gün
ROI: 1 hesap açılışı = $200-500 komisyon

---

## Destek Kanalları

- Vapi docs: https://docs.vapi.ai
- Supabase docs: https://supabase.com/docs
- ElevenLabs docs: https://docs.elevenlabs.io
