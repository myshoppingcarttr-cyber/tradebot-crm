-- ============================================
-- TRADEBOT CRM — Supabase SQL Şeması
-- Forex AI Call Center + Piyasa Analizi
-- ============================================

-- -----------------------------------------------
-- 1. LEADS (Ana müşteri / lead tablosu)
-- -----------------------------------------------
create table leads (
  id               uuid primary key default gen_random_uuid(),
  full_name        text not null,
  phone            text unique not null,
  email            text,
  city             text,
  country          text default 'TR',
  age              int,
  language         text default 'tr',

  -- İlgi alanları
  interests        text[],          -- ['gold','crypto','forex','cfd','stocks']
  risk_profile     text,            -- 'conservative' | 'moderate' | 'aggressive'
  estimated_capital text,           -- '<1k' | '1k-10k' | '10k-50k' | '50k+'

  -- Lead durumu
  status           text default 'cold',  -- 'cold' | 'warm' | 'hot' | 'converted' | 'lost'
  score            int default 0,        -- 0-100 arası AI skoru
  source           text,                 -- 'csv_import' | 'web_form' | 'inbound' | 'referral'

  -- Notlar
  notes            text,
  tags             text[],

  -- Zaman damgaları
  last_called_at   timestamptz,
  converted_at     timestamptz,
  created_at       timestamptz default now(),
  updated_at       timestamptz default now()
);

-- İndeksler
create index idx_leads_status  on leads(status);
create index idx_leads_score   on leads(score desc);
create index idx_leads_phone   on leads(phone);


-- -----------------------------------------------
-- 2. CALLS (Arama kayıtları)
-- -----------------------------------------------
create table calls (
  id               uuid primary key default gen_random_uuid(),
  lead_id          uuid references leads(id) on delete set null,

  -- Vapi bilgileri
  vapi_call_id     text unique,
  direction        text not null,   -- 'inbound' | 'outbound'

  -- Arama detayları
  phone_from       text,
  phone_to         text,
  duration_sec     int default 0,
  status           text,            -- 'completed' | 'no_answer' | 'busy' | 'failed'

  -- İçerik
  transcript       text,            -- Tam konuşma metni
  summary          text,            -- AI özeti
  sentiment        text,            -- 'positive' | 'neutral' | 'negative'
  outcome          text,            -- 'appointment' | 'account_opened' | 'callback' | 'not_interested' | 'info_given'

  -- Skor & flag
  lead_score_after int,             -- Aramadan sonra güncellenen skor
  escalated        boolean default false,  -- Canlı temsilciye aktarıldı mı

  -- Piyasa bağlamı (hangi analizle arandı)
  market_context   jsonb,           -- O günün piyasa verisi snapshot'ı

  called_at        timestamptz default now(),
  created_at       timestamptz default now()
);

create index idx_calls_lead_id   on calls(lead_id);
create index idx_calls_called_at on calls(called_at desc);
create index idx_calls_outcome   on calls(outcome);


-- -----------------------------------------------
-- 3. APPOINTMENTS (Randevular)
-- -----------------------------------------------
create table appointments (
  id               uuid primary key default gen_random_uuid(),
  lead_id          uuid references leads(id) on delete cascade,
  call_id          uuid references calls(id) on delete set null,

  -- Randevu detayı
  scheduled_at     timestamptz not null,
  duration_min     int default 30,
  medium           text default 'phone',  -- 'phone' | 'video' | 'in_person'
  advisor_name     text,

  -- Durum
  status           text default 'scheduled',  -- 'scheduled' | 'completed' | 'cancelled' | 'no_show'
  notes            text,

  -- Hatırlatma
  reminder_sent    boolean default false,
  reminder_sent_at timestamptz,

  created_at       timestamptz default now()
);

create index idx_appt_lead_id      on appointments(lead_id);
create index idx_appt_scheduled_at on appointments(scheduled_at);


-- -----------------------------------------------
-- 4. DAILY_ANALYSIS (Günlük piyasa analizi)
-- Ajan bu tablodan beslenecek
-- -----------------------------------------------
create table daily_analysis (
  id               uuid primary key default gen_random_uuid(),
  analysis_date    date unique not null default current_date,

  -- Ham piyasa verileri (API'den gelen)
  market_data      jsonb not null,
  /*
    Örnek market_data yapısı:
    {
      "XAUUSD": { "price": 2354.80, "change_pct": 1.24, "direction": "up" },
      "EURUSD": { "price": 1.0891,  "change_pct": 0.31, "direction": "up" },
      "BTCUSD": { "price": 68420,   "change_pct": 2.87, "direction": "up" },
      "BRENT":  { "price": 88.14,   "change_pct": -0.92,"direction": "down" }
    }
  */

  -- AI tarafından üretilen analizler
  gold_analysis    text,    -- Altın için satış narrative
  fx_analysis      text,    -- Forex için satış narrative
  crypto_analysis  text,    -- Kripto için satış narrative
  stocks_analysis  text,    -- Hisse / endeks analizi
  general_summary  text,    -- Genel piyasa özeti

  -- Satış script'leri (ürüne göre)
  sales_scripts    jsonb,
  /*
    Örnek sales_scripts yapısı:
    {
      "gold_opener":   "Bugün altın 2,354'e ulaştı, bu yılın zirvesine yaklaşıyor...",
      "crypto_opener": "Bitcoin halving'e 20 gün kaldı, tarihsel olarak...",
      "fx_opener":     "Euro bugün dolar karşısında güçlendi, bu dalgalanmadan...",
      "urgency_hook":  "Bugün 16:00'da açıklanacak ABD enflasyon verisi..."
    }
  */

  -- Önemli haber & takvim
  news_events      jsonb,
  /*
    [
      { "time": "16:00", "event": "USD CPI YoY", "forecast": "3.4%", "impact": "high" },
      { "time": "18:30", "event": "Fed Konuşması", "impact": "high" }
    ]
  */

  -- Vapi sistem promptuna enjekte edilecek hazır metin
  vapi_prompt_inject text,

  fetched_at       timestamptz default now(),
  created_at       timestamptz default now()
);

create index idx_daily_analysis_date on daily_analysis(analysis_date desc);


-- -----------------------------------------------
-- 5. OUTBOUND_CAMPAIGNS (Toplu arama kampanyaları)
-- -----------------------------------------------
create table outbound_campaigns (
  id               uuid primary key default gen_random_uuid(),
  name             text not null,
  description      text,

  -- Hedef kitle filtresi
  target_filter    jsonb,
  /*
    {
      "status": ["cold", "warm"],
      "interests": ["gold"],
      "min_score": 0,
      "max_score": 60,
      "city": ["Istanbul", "Ankara"]
    }
  */

  -- Kullanılacak script
  script_type      text,   -- 'gold' | 'crypto' | 'forex' | 'general'
  vapi_assistant_id text,

  -- İstatistikler
  total_leads      int default 0,
  called_count     int default 0,
  answered_count   int default 0,
  converted_count  int default 0,

  -- Durum
  status           text default 'draft',  -- 'draft' | 'running' | 'paused' | 'completed'
  scheduled_at     timestamptz,
  started_at       timestamptz,
  completed_at     timestamptz,

  created_at       timestamptz default now()
);


-- -----------------------------------------------
-- 6. LEAD_SCORE_LOG (Skor değişim geçmişi)
-- -----------------------------------------------
create table lead_score_log (
  id          uuid primary key default gen_random_uuid(),
  lead_id     uuid references leads(id) on delete cascade,
  old_score   int,
  new_score   int,
  reason      text,   -- 'answered_call' | 'requested_demo' | 'no_answer' | 'rejected'
  call_id     uuid references calls(id) on delete set null,
  created_at  timestamptz default now()
);

create index idx_score_log_lead_id on lead_score_log(lead_id);


-- -----------------------------------------------
-- FUNCTIONS & TRIGGERS
-- -----------------------------------------------

-- Lead skoru otomatik güncelle
create or replace function update_lead_score()
returns trigger as $$
begin
  update leads
  set
    score      = new.lead_score_after,
    status     = case
                   when new.lead_score_after >= 80 then 'hot'
                   when new.lead_score_after >= 50 then 'warm'
                   when new.outcome = 'account_opened' then 'converted'
                   else 'cold'
                 end,
    last_called_at = new.called_at,
    updated_at = now()
  where id = new.lead_id;
  return new;
end;
$$ language plpgsql;

create trigger trg_update_lead_after_call
after insert or update on calls
for each row
when (new.lead_id is not null and new.lead_score_after is not null)
execute function update_lead_score();


-- updated_at otomatik güncelle
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_leads_updated_at
before update on leads
for each row execute function set_updated_at();


-- -----------------------------------------------
-- Row Level Security (RLS)
-- -----------------------------------------------
alter table leads              enable row level security;
alter table calls              enable row level security;
alter table appointments       enable row level security;
alter table daily_analysis     enable row level security;
alter table outbound_campaigns enable row level security;

-- Service role tam erişim (backend için)
create policy "service_role_all" on leads
  for all using (auth.role() = 'service_role');

create policy "service_role_all" on calls
  for all using (auth.role() = 'service_role');

create policy "service_role_all" on appointments
  for all using (auth.role() = 'service_role');

create policy "service_role_all" on daily_analysis
  for all using (auth.role() = 'service_role');

create policy "service_role_all" on outbound_campaigns
  for all using (auth.role() = 'service_role');


-- -----------------------------------------------
-- TEST VERİSİ (Opsiyonel)
-- -----------------------------------------------
insert into leads (full_name, phone, city, interests, status, score, source) values
  ('Ahmet Kaya',    '+905320000001', 'Istanbul', array['gold','forex'],  'hot',  92, 'csv_import'),
  ('Fatma Demir',   '+905550000002', 'Izmir',    array['crypto','cfd'],  'hot',  88, 'inbound'),
  ('Mehmet Balcı',  '+905060000003', 'Ankara',   array['cfd','commodity'],'warm', 72, 'csv_import'),
  ('Hasan Yılmaz',  '+905440000004', 'Bursa',    array['stocks'],        'cold', 35, 'csv_import'),
  ('Zeynep Arslan', '+905350000005', 'Istanbul', array['crypto'],        'warm', 58, 'outbound');
