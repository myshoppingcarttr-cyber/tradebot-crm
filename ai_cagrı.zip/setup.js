// ============================================================
// TRADEBOT - VAPİ ASSISTANT KURULUM SCRIPTI
// Bu dosyayı bir kez çalıştır, assistant'ı oluşturur
// ============================================================

require('dotenv').config();

const ASSISTANT_CONFIG = {
  name: "TradebotCRM - Ayşe",

  // ---- SES AYARLARI ----
  voice: {
    provider: "11labs",
    voiceId: process.env.ELEVENLABS_VOICE_ID,  // Türkçe kadın ses
    stability: 0.5,
    similarityBoost: 0.75,
    style: 0.0,
    useSpeakerBoost: true
  },

  // ---- LLM AYARLARI ----
  model: {
    provider: "anthropic",
    model: "claude-sonnet-4-20250514",
    temperature: 0.7,
    maxTokens: 1000,
    // System prompt her sabah marketAnalysis servisi tarafından güncellenir
    systemPrompt: "Sen TradebotCRM'in AI satış asistanısın. Sistem başlatılıyor..."
  },

  // ---- TOOL TANIMLARI (Webhook'a bağlanır) ----
  tools: [
    {
      type: "function",
      function: {
        name: "get_lead_info",
        description: "Aranan müşterinin CRM bilgilerini ve önceki arama geçmişini getirir. Arama başında çağır.",
        parameters: {
          type: "object",
          properties: {
            phone: {
              type: "string",
              description: "Müşterinin telefon numarası (uluslararası format: +90...)"
            }
          },
          required: ["phone"]
        }
      }
    },
    {
      type: "function",
      function: {
        name: "get_market_data",
        description: "Bugünün piyasa verilerini ve AI satış analizini getirir. Piyasadan bahsederken çağır.",
        parameters: {
          type: "object",
          properties: {},
          required: []
        }
      }
    },
    {
      type: "function",
      function: {
        name: "save_lead",
        description: "Yeni müşteriyi veya güncellenen bilgileri CRM'e kaydeder.",
        parameters: {
          type: "object",
          properties: {
            phone:    { type: "string", description: "Telefon numarası" },
            name:     { type: "string", description: "Ad soyad" },
            email:    { type: "string", description: "E-posta" },
            city:     { type: "string", description: "Şehir" },
            interest: { type: "string", description: "İlgi alanı: gold, forex, crypto, stocks, cfd" },
            notes:    { type: "string", description: "Konuşmadan önemli notlar" }
          },
          required: ["phone"]
        }
      }
    },
    {
      type: "function",
      function: {
        name: "update_lead_status",
        description: "Konuşma sonunda müşterinin durumunu ve sıcaklık skorunu günceller.",
        parameters: {
          type: "object",
          properties: {
            phone:  { type: "string" },
            status: {
              type: "string",
              enum: ["hot", "warm", "cold", "converted", "do_not_call"],
              description: "Müşterinin yeni durumu"
            },
            score: {
              type: "number",
              description: "Sıcaklık skoru 0-100"
            },
            notes: { type: "string", description: "Konuşma özeti" }
          },
          required: ["phone", "status"]
        }
      }
    },
    {
      type: "function",
      function: {
        name: "create_appointment",
        description: "Müşteri randevu kabul ettiğinde randevu oluşturur.",
        parameters: {
          type: "object",
          properties: {
            phone:        { type: "string" },
            date_time:    { type: "string", description: "ISO format: 2025-04-14T14:00:00" },
            subject:      {
              type: "string",
              enum: ["demo_account", "investment_plan", "follow_up"],
              description: "Randevu konusu"
            },
            advisor_name: { type: "string", description: "Danışman adı" }
          },
          required: ["phone", "date_time"]
        }
      }
    }
  ],

  // ---- ÇAĞRI AYARLARI ----
  serverUrl: `${process.env.WEBHOOK_BASE_URL}/webhook/vapi`,

  // ---- SES TESPİT / KONUŞMA AKIŞI ----
  silenceTimeoutSeconds: 30,
  maxDurationSeconds: 600,   // Maks 10 dakika

  // Müşteri konuşmayı bitirince
  endCallMessage: "Görüşmemiz için teşekkür ederim. İyi günler dilerim.",
  endCallPhrases: ["görüşürüz", "hoşça kal", "kapayacağım", "tamam teşekkürler"],

  // İlk konuşma — müşteriyi karşıla
  firstMessage: "Merhaba! Ben Ayşe, finansal danışmanlık hizmetleri sunuyorum. Size nasıl yardımcı olabilirim?",

  // ---- OUTBOUND İÇİN ÖZEL AÇILIŞ ----
  // (Outbound aramalarda overrideMessage ile değiştirilir)
};

// ============================================================
// ASSISTANT OLUŞTUR
// ============================================================
async function createAssistant() {
  console.log('[VAPI] Assistant oluşturuluyor...');

  const response = await fetch('https://api.vapi.ai/assistant', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.VAPI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(ASSISTANT_CONFIG)
  });

  const data = await response.json();

  if (!response.ok) {
    console.error('[VAPI] Hata:', data);
    throw new Error(JSON.stringify(data));
  }

  console.log('[VAPI] Assistant oluşturuldu!');
  console.log('Assistant ID:', data.id);
  console.log('>>> .env dosyana ekle: VAPI_ASSISTANT_ID=' + data.id);

  return data;
}

// ============================================================
// OUTBOUND ARAMA BAŞLAT
// ============================================================
async function makeOutboundCall({ phone, leadName, leadInterest, customOpeningLine }) {
  // Kişiye özel açılış mesajı
  const firstMessage = customOpeningLine
    || `Merhaba, ${leadName || 'sayın yatırımcı'}! Ben Ayşe, ${
        leadInterest?.includes('gold')   ? 'altın piyasasında' :
        leadInterest?.includes('crypto') ? "kripto'da" :
        leadInterest?.includes('forex')  ? 'döviz piyasalarında' :
        'finansal piyasalarda'
      } harika fırsatlar var, sizinle paylaşmak istedim.`;

  const response = await fetch('https://api.vapi.ai/call/phone', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.VAPI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      assistantId:   process.env.VAPI_ASSISTANT_ID,
      phoneNumberId: process.env.VAPI_PHONE_NUMBER_ID,
      customer: {
        number: phone,
        name:   leadName || undefined
      },
      assistantOverrides: {
        firstMessage,
        variableValues: {
          customerName:    leadName,
          customerInterest: leadInterest?.join(', ')
        }
      }
    })
  });

  const data = await response.json();
  if (!response.ok) throw new Error(JSON.stringify(data));

  return { call_id: data.id, status: data.status };
}

// ============================================================
// OUTBOUND KAMPANYA — Supabase'den lead listesi al, toplu ara
// ============================================================
async function runOutboundCampaign({ filter = {}, maxCalls = 50, delayMs = 3000 }) {
  const { createClient } = require('@supabase/supabase-js');
  const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

  // Filtre uygula
  let query = supabase.from('leads')
    .select('*')
    .neq('status', 'do_not_call')
    .neq('status', 'converted')
    .lt('call_count', 5)       // 5'ten fazla aranmış leadleri atla
    .order('score', { ascending: false })
    .limit(maxCalls);

  if (filter.status) query = query.eq('status', filter.status);
  if (filter.interest) query = query.contains('interest', [filter.interest]);
  if (filter.city) query = query.eq('city', filter.city);

  const { data: leads, error } = await query;
  if (error) throw error;

  console.log(`[CAMPAIGN] ${leads.length} lead bulundu, aramalar başlıyor...`);

  let called = 0, failed = 0;

  for (const lead of leads) {
    try {
      const result = await makeOutboundCall({
        phone:        lead.phone,
        leadName:     lead.name,
        leadInterest: lead.interest
      });

      console.log(`[CAMPAIGN] ✓ ${lead.name || lead.phone} → ${result.call_id}`);
      called++;

      // Rate limiting — aramalar arasında bekle
      await new Promise(r => setTimeout(r, delayMs));

    } catch (err) {
      console.error(`[CAMPAIGN] ✗ ${lead.phone}:`, err.message);
      failed++;
    }
  }

  console.log(`[CAMPAIGN] Tamamlandı: ${called} başarılı, ${failed} başarısız`);
  return { called, failed, total: leads.length };
}

// ============================================================
// CLI KULLANIMI
// node vapiSetup.js create     → Assistant oluştur
// node vapiSetup.js campaign   → Kampanya başlat
// ============================================================
if (require.main === module) {
  const cmd = process.argv[2];

  if (cmd === 'create') {
    createAssistant().catch(console.error);

  } else if (cmd === 'campaign') {
    runOutboundCampaign({
      filter:   { status: 'cold' },
      maxCalls: 100,
      delayMs:  2000
    }).catch(console.error);

  } else {
    console.log('Kullanım: node vapiSetup.js [create|campaign]');
  }
}

module.exports = { createAssistant, makeOutboundCall, runOutboundCampaign };
