// ============================================================
// TRADEBOT - GÜNLÜK PİYASA ANALİZ SERVİSİ
// Her sabah 08:00'de çalışır, veriyi çeker ve AI analiz üretir
// Vapi agent prompt'una otomatik enjekte edilir
// ============================================================

const { createClient } = require('@supabase/supabase-js');
const Anthropic = require('@anthropic-ai/sdk');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ============================================================
// ANA FONKSİYON — Her sabah Make.com veya cron tetikler
// ============================================================
async function runDailyAnalysis() {
  console.log('[ANALYSIS] Günlük piyasa analizi başlıyor...');

  try {
    // 1. Piyasa verilerini çek
    const markets = await fetchMarketData();
    console.log('[ANALYSIS] Piyasa verileri alındı:', Object.keys(markets));

    // 2. Ekonomik takvim çek
    const events = await fetchEconomicCalendar();

    // 3. AI ile satış odaklı analiz üret
    const analysis = await generateSalesAnalysis(markets, events);

    // 4. Supabase'e kaydet
    const today = new Date().toISOString().split('T')[0];
    await supabase.from('daily_analysis').upsert({
      analysis_date: today,
      markets,
      ai_summary:    analysis.summary,
      sales_scripts: analysis.scripts,
      objection_tips: analysis.objections,
      key_events:    events,
      sentiment:     analysis.sentiment
    }, { onConflict: 'analysis_date' });

    // 5. Vapi assistant prompt'unu güncelle
    await updateVapiPrompt(analysis, markets, events);

    console.log('[ANALYSIS] Tamamlandı. Tarih:', today);
    return { success: true, date: today };

  } catch (err) {
    console.error('[ANALYSIS] Hata:', err);
    return { success: false, error: err.message };
  }
}

// ============================================================
// PİYASA VERİSİ — Yahoo Finance (ücretsiz, key gerekmez)
// ============================================================
async function fetchMarketData() {
  const symbols = {
    'XAUUSD': { name: 'Altın', category: 'commodity' },
    'EURUSD': { name: 'EUR/USD', category: 'forex' },
    'GBPUSD': { name: 'GBP/USD', category: 'forex' },
    'USDTRY': { name: 'USD/TRY', category: 'forex' },
    'BTC-USD': { name: 'Bitcoin', category: 'crypto' },
    'ETH-USD': { name: 'Ethereum', category: 'crypto' },
    'SPY':     { name: 'S&P 500', category: 'index' },
    'BZ=F':    { name: 'Brent Petrol', category: 'commodity' },
  };

  const markets = {};

  for (const [symbol, meta] of Object.entries(symbols)) {
    try {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=2d`;
      const response = await fetch(url);
      const data = await response.json();

      const result = data.chart?.result?.[0];
      if (!result) continue;

      const quotes = result.indicators.quote[0];
      const closes = quotes.close.filter(Boolean);
      const currentPrice = closes[closes.length - 1];
      const prevPrice    = closes[closes.length - 2] || currentPrice;
      const changePct    = ((currentPrice - prevPrice) / prevPrice) * 100;

      markets[symbol] = {
        name:       meta.name,
        category:   meta.category,
        price:      Math.round(currentPrice * 100) / 100,
        change_pct: Math.round(changePct * 100) / 100,
        direction:  changePct > 0.1 ? 'up' : changePct < -0.1 ? 'down' : 'flat',
        prev_price: Math.round(prevPrice * 100) / 100
      };

    } catch (err) {
      console.error(`[MARKET] ${symbol} alınamadı:`, err.message);
    }
  }

  return markets;
}

// ============================================================
// EKONOMİK TAKVİM — Önemli günlük olaylar
// ============================================================
async function fetchEconomicCalendar() {
  // Not: Gerçek uygulamada investing.com scrape veya
  // TradingEconomics API kullanılabilir.
  // Şimdilik statik + dinamik karışık örnek döndürüyoruz.

  const today = new Date();
  const days = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
  const dayName = days[today.getDay()];

  // Sabit haftalık olaylar
  const weeklyEvents = {
    1: ['EUR Sentix Yatırımcı Güveni 10:30'],
    2: ['USD Enflasyon Beklentileri 17:00', 'USD API Ham Petrol Stokları 22:30'],
    3: ['Fed Tutanakları 21:00', 'USD EIA Ham Petrol Stokları 17:30'],
    4: ['USD Haftalık İşsizlik Başvuruları 15:30', 'ECB Konuşması'],
    5: ['EUR TÜFE Verisi 12:00', 'USD Tarım Dışı İstihdam 15:30'],
  };

  return weeklyEvents[today.getDay()] || [`${dayName} için önemli ekonomik veri beklenmemektedir.`];
}

// ============================================================
// AI ANALİZ ÜRETİCİ — Claude ile satış odaklı analiz
// ============================================================
async function generateSalesAnalysis(markets, events) {
  const marketText = Object.entries(markets)
    .map(([sym, d]) => `${d.name} (${sym}): ${d.price} | ${d.change_pct > 0 ? '+' : ''}${d.change_pct}% | ${d.direction === 'up' ? '▲ YUKARI' : d.direction === 'down' ? '▼ AŞAĞI' : '— YATAY'}`)
    .join('\n');

  const prompt = `Sen bir yatırım ürünleri satış direktörüsün. Aşağıdaki piyasa verilerini kullanarak bir AI telefon satış ajanı için günlük brifing hazırla.

BUGÜNKÜ PİYASA VERİLERİ:
${marketText}

ÖNEMLİ EKONOMİK OLAYLAR:
${events.join('\n')}

Lütfen aşağıdaki formatta JSON döndür (başka hiçbir şey yazma):
{
  "sentiment": "bullish|bearish|neutral|volatile",
  "summary": "Ajana verilecek 3-4 cümlelik piyasa özeti. Hangi ürünlerde fırsat var, neden şimdi doğru zaman. Satış odaklı yaz.",
  "scripts": {
    "gold": "Altın yatırımcısıyla konuşurken kullanılacak 2-3 cümlelik açılış. Bugünkü hareketi kullan.",
    "forex": "Forex yatırımcısıyla konuşma scripti. Volatiliteyi fırsata çevir.",
    "crypto": "Kripto yatırımcısı için açılış scripti.",
    "stocks": "Hisse/endeks yatırımcısı için açılış scripti."
  },
  "objections": {
    "risk": "Bugünkü piyasaya özel risk itirazı karşılama",
    "timing": "Bugün neden doğru zaman olduğuna dair 2 cümle",
    "trust": "Güven itirazı için genel karşılama"
  },
  "urgency_hook": "Bugüne özel aciliyet yaratacak 1 cümle"
}`;

  const response = await anthropic.messages.create({
    model:      'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages:   [{ role: 'user', content: prompt }]
  });

  const text = response.content[0].text.trim();
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

// ============================================================
// VAPİ PROMPT GÜNCELLE — Günlük analizi ajana enjekte et
// ============================================================
async function updateVapiPrompt(analysis, markets, events) {
  const today = new Date().toLocaleDateString('tr-TR', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });

  // Öne çıkan piyasaları bul
  const topMovers = Object.values(markets)
    .sort((a, b) => Math.abs(b.change_pct) - Math.abs(a.change_pct))
    .slice(0, 3)
    .map(m => `${m.name}: ${m.change_pct > 0 ? '+' : ''}${m.change_pct}%`)
    .join(', ');

  const systemPrompt = buildSystemPrompt(analysis, markets, events, today, topMovers);

  // Vapi assistant'ı güncelle
  const response = await fetch(`https://api.vapi.ai/assistant/${process.env.VAPI_ASSISTANT_ID}`, {
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${process.env.VAPI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: {
        provider: 'anthropic',
        model: 'claude-sonnet-4-20250514',
        systemPrompt
      }
    })
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Vapi prompt güncellenemedi: ${err}`);
  }

  console.log('[VAPI] System prompt başarıyla güncellendi.');
}

// ============================================================
// SYSTEM PROMPT BUILDER
// ============================================================
function buildSystemPrompt(analysis, markets, events, today, topMovers) {
  return `Sen deneyimli bir finansal ürünler satış uzmanısın. Adın Ayşe. Uluslararası lisanslı bir aracı kurumun Türk pazarı satış temsilcisisin.

## BUGÜN: ${today}
## PİYASA DURUMU: ${analysis.sentiment.toUpperCase()}

### GÜNLÜK PİYASA ÖZETİ (BUNU KONUŞMAYA ENTEGRE ET)
${analysis.summary}

### ÖNE ÇIKAN HAREKETLER
${topMovers}

### ÖNEMLİ GÜNLÜK OLAYLAR
${events.join('\n')}

### ÜRÜN BAZLI AÇILIŞ SCRİPTLERİ
- ALTIN: "${analysis.scripts.gold}"
- FOREX: "${analysis.scripts.forex}"
- KRİPTO: "${analysis.scripts.crypto}"
- HİSSE: "${analysis.scripts.stocks}"

### BUGÜNE ÖZEL ACİLİYET
"${analysis.urgency_hook}"

---

## KONUŞMA KURALLARI

**AÇILIŞ**: Müşterinin adını kullan, sıcak ve enerjik başla. İlk 10 saniyede bir piyasa gerçeğiyle ilgi çek.

**DİNLEME**: Müşterinin ilgi alanını anlamaya çalış. Hangi ürüne yönlendireceğini belirle.

**HEDEF SIRALAMASI**:
1. Demo hesap açılışı (en kolay, risksiz)
2. Randevu (uzman danışmanla görüşme)
3. Gerçek hesap açılışı
4. Callback (geri arama sözü)

**İTİRAZ KARŞILAMA**:
- "İlgilenmiyorum" → "${analysis.objections.timing}"
- "Riskli" → "${analysis.objections.risk}"
- "Güvenmiyorum" → "${analysis.objections.trust}"
- "Param yok" → "Demo hesapla başlayabilirsiniz, gerçek para yok, sıfır risk."
- "Düşüneceğim" → "${analysis.urgency_hook}"

**AKTARMA**: Müşteri sıcaklaştığında "Sizi hemen uzman danışmanımız [İsim]'e bağlayayım" de ve transfer et.

**KESİNLİKLE YAPMA**:
- Garantili getiri vaat etme
- Baskı uygulama
- 3 kez "hayır" dedikten sonra ısrar etme
- Rakip şirketler hakkında yorum yapma

**TOOL KULLANIMI**:
- Arama başında: get_lead_info ile müşteriyi tanı
- Konuşma boyunca: get_market_data ile güncel veriyi kontrol et  
- İlgilenen müşteri: save_lead ile kaydet, update_lead_status ile skoru güncelle
- Randevu: create_appointment ile oluştur
- Arama sonu: update_lead_status ile sonucu kaydet

Her zaman Türkçe konuş. Doğal, samimi ve profesyonel ol.`;
}

// ============================================================
// HTTP ENDPOINT — Make.com veya cron bu URL'yi çağırır
// ============================================================
const express = require('express');
const router = express.Router();

router.post('/run-daily-analysis', async (req, res) => {
  // Basit API key kontrolü
  const apiKey = req.headers['x-api-key'];
  if (apiKey !== process.env.INTERNAL_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const result = await runDailyAnalysis();
  res.json(result);
});

module.exports = { router, runDailyAnalysis };
